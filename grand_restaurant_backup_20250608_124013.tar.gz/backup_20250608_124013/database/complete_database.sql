PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE menu_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            category VARCHAR(50) NOT NULL,
            image_url VARCHAR(255),
            is_available BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
INSERT INTO menu_items VALUES(59,'Test Rice Curry','A delicious test item',750,'Rice & Curry','images/popular/1.png',0,'2025-06-05 19:52:48','2025-06-05 19:52:48');
INSERT INTO menu_items VALUES(60,'Sweet and Sour Chicken','Chinese style chicken',950,'Chinese','images/popular/2.png',1,'2025-06-05 19:52:58','2025-06-05 19:52:58');
INSERT INTO menu_items VALUES(61,'Special Fusion Dish','Our chef special creation',1200,'Other Specialties','images/popular/3.png',1,'2025-06-05 19:53:06','2025-06-05 19:53:06');
INSERT INTO menu_items VALUES(64,'Seafood Platter','Fresh mixed seafood with rice and vegetables',28.98999999999999844,'Seafood','https://via.placeholder.com/300x200?text=Seafood+Platter',1,'2025-06-05 20:08:06','2025-06-05 20:08:06');
INSERT INTO menu_items VALUES(65,'Chicken Kottu','Traditional Sri Lankan street food with chicken and vegetables',15.99000000000000021,'Kottu','https://via.placeholder.com/300x200?text=Chicken+Kottu',1,'2025-06-05 20:08:14','2025-06-05 20:08:14');
INSERT INTO menu_items VALUES(67,'Fresh Orange Juice','Freshly squeezed orange juice',4.990000000000000213,'Juices','https://via.placeholder.com/300x200?text=Orange+Juice',1,'2025-06-05 20:08:27','2025-06-05 20:08:27');
INSERT INTO menu_items VALUES(68,'Watalappan','Traditional Sri Lankan coconut custard dessert',6.990000000000000213,'Desserts','https://via.placeholder.com/300x200?text=Watalappan',1,'2025-06-05 20:08:35','2025-06-05 20:08:35');
INSERT INTO menu_items VALUES(69,'Traditional Rice & Curry','A hearty plate of steamed rice served with a variety of traditional curries including dhal, vegetable curry, and chicken curry',12.99000000000000021,'Rice & Curry','/images/rice-curry.jpg',1,'2025-06-05 22:01:25','2025-06-05 22:01:25');
CREATE TABLE reservations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name VARCHAR(100) NOT NULL,
            customer_email VARCHAR(100) NOT NULL,
            customer_phone VARCHAR(20),
            reservation_date DATE NOT NULL,
            reservation_time TIME NOT NULL,
            party_size INTEGER NOT NULL,
            special_requests TEXT,
            status VARCHAR(20) DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
CREATE TABLE orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name VARCHAR(100) NOT NULL,
            customer_email VARCHAR(100) NOT NULL,
            customer_phone VARCHAR(20),
            delivery_address TEXT,
            total_amount DECIMAL(10,2) NOT NULL,
            status VARCHAR(20) DEFAULT 'pending',
            order_type VARCHAR(20) DEFAULT 'delivery',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
INSERT INTO orders VALUES(18,'anjula prasad','prasadanjula1@gmail.com','0771950486','',1200,'pending','pickup','2025-06-07 19:16:10','2025-06-07 19:16:10');
CREATE TABLE order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            menu_item_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
        );
INSERT INTO order_items VALUES(1,1,1,2,450);
INSERT INTO order_items VALUES(2,1,2,1,650);
INSERT INTO order_items VALUES(3,2,3,1,850);
INSERT INTO order_items VALUES(4,3,1,1,450);
INSERT INTO order_items VALUES(5,3,4,1,200);
INSERT INTO order_items VALUES(6,4,1,3,450);
INSERT INTO order_items VALUES(7,4,2,1,650);
INSERT INTO order_items VALUES(8,5,20,2,1200);
INSERT INTO order_items VALUES(9,5,11,1,1150);
INSERT INTO order_items VALUES(10,5,9,1,850);
INSERT INTO order_items VALUES(11,6,1,2,15.99000000000000021);
INSERT INTO order_items VALUES(12,7,2,1,12.5);
INSERT INTO order_items VALUES(13,8,3,3,8.75);
INSERT INTO order_items VALUES(14,9,1,1,20);
INSERT INTO order_items VALUES(15,10,2,2,15);
INSERT INTO order_items VALUES(16,11,58,2,456);
INSERT INTO order_items VALUES(17,12,69,2,12.99000000000000021);
INSERT INTO order_items VALUES(18,13,69,1,12.99000000000000021);
INSERT INTO order_items VALUES(19,14,60,3,950);
INSERT INTO order_items VALUES(20,15,69,1,12.99000000000000021);
INSERT INTO order_items VALUES(21,16,69,1,12.99000000000000021);
INSERT INTO order_items VALUES(22,17,69,1,12.99000000000000021);
INSERT INTO order_items VALUES(23,18,61,1,1200);
CREATE TABLE reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name VARCHAR(100) NOT NULL,
            customer_email VARCHAR(100) NOT NULL,
            rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
            review_text TEXT,
            is_approved BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
INSERT INTO reviews VALUES(33,'Test User','',5,'This is a test review with more than 10 characters to check validation.',1,'2025-06-07 08:33:00');
INSERT INTO reviews VALUES(35,'Test User','',5,'This is a test review with sufficient length',1,'2025-06-07 08:40:24');
INSERT INTO reviews VALUES(36,'madhawa','',1,'tharahai oyth ekk mn',1,'2025-06-07 08:42:32');
INSERT INTO reviews VALUES(37,'dont','',3,'hodi hodi hodi dannam',1,'2025-06-07 08:47:55');
INSERT INTO reviews VALUES(38,'anjula prasad','',1,'good food tase. rasai gdk',1,'2025-06-07 08:50:37');
INSERT INTO reviews VALUES(39,'kaputa','',3,'kaak kaak kaak kaak',1,'2025-06-07 08:53:33');
CREATE TABLE admin_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            email VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
INSERT INTO admin_users VALUES(1,'admin','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin@grandrestaurant.com','2025-06-02 11:16:15');
CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            phone VARCHAR(20),
            password_hash VARCHAR(255) NOT NULL,
            address TEXT,
            date_of_birth DATE,
            email_verified BOOLEAN DEFAULT 0,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP NULL
        );
INSERT INTO users VALUES(1,'MAMP','User','mampuser@example.com','1234567890','$2y$10$k9y08.g/JbLSfUsC9DjnQekLfZ97W/.G3iSTAL34.juaDIoMx7.iu','',NULL,0,1,'2025-06-02 11:16:22','2025-06-02 11:16:22','2025-06-02 11:16:22');
INSERT INTO users VALUES(2,'anju','pu','anju@gmail.com','0909088787','$2y$10$LsR25lD36GehvDW94XHZGuZ4.GPyBGuPat4NrogBULUMyHGHjcjkq','asd,jhgd','2025-06-13',0,1,'2025-06-02 11:19:59','2025-06-02 11:19:59','2025-06-02 11:30:07');
INSERT INTO users VALUES(3,'Test','User','test@example.com','','$2y$12$BvhanhnSWiMTmGjcB5r7S.mXlcnpSBmhkuh4kqKfsSeUoSZQGKfRy','',NULL,0,1,'2025-06-02 22:48:19','2025-06-02 22:48:19','2025-06-02 22:48:19');
INSERT INTO users VALUES(4,'Jane','Doe','jane@example.com','','$2y$12$WkX/PmgYKn4nsZPIprl6N.pY26BNkcp0OveG9erczzY8q6/7P8H4C','',NULL,0,1,'2025-06-02 22:49:08','2025-06-02 22:49:08','2025-06-02 22:49:09');
INSERT INTO users VALUES(5,'Final','Test','finaltest@example.com','555-123-4567','$2y$12$j.FtMr2pLIHVcLs7IZpK2uhyJ./2LWqdjZihZyTKaXVy3eBCSJIDu','123 Test Street',NULL,0,1,'2025-06-02 22:51:08','2025-06-02 22:51:08','2025-06-02 22:51:14');
INSERT INTO users VALUES(6,'anjula','prasad','prasadanjula1@gmail.com','0771950486','$2y$10$qo3DaUf2dmiTVBXWLvcZKOaAq2B5s/RHlMWKn0xgL25aeVAHeIXVG',replace('70000\n70000','\n',char(10)),'2001-11-03',0,1,'2025-06-02 22:52:33','2025-06-02 23:00:54','2025-06-07 19:15:57');
CREATE TABLE initialization_marker (initialized_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
INSERT INTO initialization_marker VALUES('2025-06-05 13:57:13');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('reviews',39);
INSERT INTO sqlite_sequence VALUES('admin_users',3);
INSERT INTO sqlite_sequence VALUES('users',6);
INSERT INTO sqlite_sequence VALUES('orders',18);
INSERT INTO sqlite_sequence VALUES('order_items',23);
INSERT INTO sqlite_sequence VALUES('menu_items',70);
INSERT INTO sqlite_sequence VALUES('reservations',27);
COMMIT;
